%%

model=tf(1,[15 1]);

%%

[y,t]=step(model);
plot(t,y)
close all;

%%

tf1=20;
[y1,t1]=step(model,tf1);
plot(t1,y1)
close all;

%%

tf2=105;
[y2,t2]=step(model,tf2);
plot(t2,y2)
close all;

%%

tr3=0:1:105;
[y3,t3]=step(model,tr3);
isequal(t3,tr3')
[t3(1) t3(16) t3(16)-t3(1) y3(16)]
plot(t3,y3)

tr4=20:1:125;
[y4,t4]=step(model,tr4);
isequal(t4,tr4')
[t4(1) t4(16) t4(16)-t4(1) y4(16)]
isequal(y4,y3)
isequal(tr4-tr4(1),tr3-tr3(1))
figure
plot(t4,y4)